# Don't use quotes( " and ' )
#SCRIPT BY VENOMxCRAZY
  
#Enter Your Bot Token here get it from @botfarher
BOT_TOKEN=("7398192648:AAHyAMqsPdN1WdVLoPubeAhEyo-mMTr7GWM")

  #Enter Your telegram username here without @
OWNER_USERNAME=("Tanveer")

  #Enter your admin id here Get it from @missRose_bot by typing /info
ADMIN_IDS=("5862766428")







  
